
class account_constants:
  CREATE = 'create'
  VERIFY = 'verify'
  DELETE = 'delete'
  LOCK = 'lock'
  PUBLIC_KEY = 'public_key'
  DISCLAIMER = 'disclaimer'
  IP = 'ip'
  LONG_KEY_ID = 'long_key_id'
