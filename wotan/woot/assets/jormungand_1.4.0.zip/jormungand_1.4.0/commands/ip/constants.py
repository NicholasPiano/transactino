
class ip_constants:
  IP_ID = 'ip_id'
