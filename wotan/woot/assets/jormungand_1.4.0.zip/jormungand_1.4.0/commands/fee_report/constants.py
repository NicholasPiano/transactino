
class fee_report_constants:
  ACTIVATE = 'activate'
  FEE_REPORT_ID = 'fee_report_id'
  BLOCKS_TO_INCLUDE = 'blocks_to_include'
  IS_ACTIVE = 'is_active'
