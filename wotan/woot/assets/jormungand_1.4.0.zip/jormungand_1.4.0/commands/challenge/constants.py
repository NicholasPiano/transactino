
class challenge_constants:
  GET = 'get'
  IS_OPEN = 'is_open'
  RESPOND = 'respond'
  DELETE = 'delete'
  CHALLENGE_ID = 'challenge_id'
  ENCRYPTED_CONTENT = 'encrypted_content'
  CONTENT = 'content'
