
class system_constants:
  GET = 'get'
  PUBLIC_KEY = 'public_key'
  GUARANTEE = 'guarantee'
  GUARANTEE_SIGNATURE = 'guarantee_signature'
  DISCLAIMER = 'disclaimer'
  DISCLAIMER_SIGNATURE = 'disclaimer_signature'
