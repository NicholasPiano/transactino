
class announcement_constants:
  GET = 'get'
