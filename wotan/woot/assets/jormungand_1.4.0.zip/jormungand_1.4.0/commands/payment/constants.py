
class payment_constants:
  GET = 'get'
  DELETE = 'delete'
  IS_OPEN = 'is_open'
  PAYMENT_ID = 'payment_id'
