
class transaction_match_constants:
  GET = 'get'
  DISMISS = 'dismiss'
  TRANSACTION_REPORT_ID = 'transaction_report_id'
  TRANSACTION_REPORT_TARGET_ADDRESS = 'transaction_report_target_address'
  TRANSACTION_REPORT_IS_ACTIVE = 'transaction_report_is_active'
  TRANSACTION_MATCH_ID = 'transaction_match_id'
  IS_NEW = 'is_new'
  BLOCK_HASH = 'block_hash'
