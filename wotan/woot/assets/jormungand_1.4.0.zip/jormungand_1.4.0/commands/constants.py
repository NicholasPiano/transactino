
class commands:
  ACCOUNT = 'account'
  CHALLENGE = 'challenge'
  SCHEMA = 'schema'
  SUBSCRIPTION = 'subscription'
  IP = 'ip'
  PAYMENT = 'payment'
  FEE_REPORT = 'fee_report'
  SYSTEM = 'system'
  ADDRESS = 'address'
  TRANSACTION_REPORT = 'transaction_report'
  TRANSACTION_MATCH = 'transaction_match'
  ANNOUNCEMENT = 'announcement'
