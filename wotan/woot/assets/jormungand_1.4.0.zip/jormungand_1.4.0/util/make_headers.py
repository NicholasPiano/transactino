
def make_headers():
  return {
    'Content-Type': 'application/json',
  }
