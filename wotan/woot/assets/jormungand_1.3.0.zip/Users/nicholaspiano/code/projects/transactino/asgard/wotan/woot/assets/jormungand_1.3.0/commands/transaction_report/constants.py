
class transaction_report_constants:
  CREATE = 'create'
  GET = 'get'
  ACTIVATE = 'activate'
  DELETE = 'delete'
  TRANSACTION_REPORT_ID = 'transaction_report_id'
  TARGET_ADDRESS = 'target_address'
  VALUE_EQUAL_TO = 'value_equal_to'
  VALUE_LESS_THAN = 'value_less_than'
  VALUE_GREATER_THAN = 'value_greater_than'
  IS_ACTIVE = 'is_active'
