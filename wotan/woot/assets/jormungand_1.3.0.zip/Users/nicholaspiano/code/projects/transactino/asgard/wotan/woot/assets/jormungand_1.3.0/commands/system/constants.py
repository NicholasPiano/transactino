
class system_constants:
  GET = 'get'
  PUBLIC_KEY = 'public_key'
