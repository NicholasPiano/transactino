
class address_constants:
  GET = 'get'
  ADDRESS_ID = 'address_id'
