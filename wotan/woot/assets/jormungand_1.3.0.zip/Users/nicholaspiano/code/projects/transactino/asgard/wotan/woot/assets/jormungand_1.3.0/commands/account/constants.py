
class account_constants:
  CREATE = 'create'
  VERIFY = 'verify'
  DELETE = 'delete'
  LOCK = 'lock'
  PUBLIC_KEY = 'public_key'
