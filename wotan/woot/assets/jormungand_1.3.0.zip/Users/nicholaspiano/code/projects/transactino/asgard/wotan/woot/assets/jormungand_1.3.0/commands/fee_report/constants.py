
class fee_report_constants:
  CREATE = 'create'
  GET = 'get'
  ACTIVATE = 'activate'
  DELETE = 'delete'
  FEE_REPORT_ID = 'fee_report_id'
  BLOCKS_TO_INCLUDE = 'blocks_to_include'
  IS_ACTIVE = 'is_active'
