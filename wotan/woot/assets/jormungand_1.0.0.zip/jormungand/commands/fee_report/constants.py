
class fee_report_constants:
  CREATE = 'create'
  GET = 'get'
  ID = 'id'
  BLOCKS_TO_INCLUDE = 'blocks_to_include'
