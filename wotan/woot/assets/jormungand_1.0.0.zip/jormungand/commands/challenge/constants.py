
class challenge_constants:
  GET = 'get'
  IS_OPEN = 'is_open'
  RESPOND = 'respond'
  CHALLENGE_ID = 'challenge_id'
  PLAINTEXT = 'plaintext'
  ENCRYPTED_CONTENT = 'encrypted_content'
