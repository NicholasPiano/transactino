
class subscription_constants:
  CREATE = 'create'
  ACTIVATE = 'activate'
  ACTIVATION_DATE = 'activation_date'
  DURATION_IN_DAYS = 'duration_in_days'
  SUBSCRIPTION_ID = 'subscription_id'
  IS_ACTIVE = 'is_active'
  GET = 'get'
