
class payment_constants:
  GET = 'get'
  IS_OPEN = 'is_open'
